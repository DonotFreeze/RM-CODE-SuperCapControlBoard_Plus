/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "SuperCapCtrl.h"
#include "PID_v1.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

extern DMA_HandleTypeDef hdma_adc1;
extern DMA_HandleTypeDef hdma_adc2;
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LED_BLUE_Pin GPIO_PIN_13
#define LED_BLUE_GPIO_Port GPIOC
#define LED_GREEN_Pin GPIO_PIN_14
#define LED_GREEN_GPIO_Port GPIOC
#define LED_RED_Pin GPIO_PIN_15
#define LED_RED_GPIO_Port GPIOC
#define I_MOS_Pin GPIO_PIN_0
#define I_MOS_GPIO_Port GPIOA
#define I_BAT_Pin GPIO_PIN_1
#define I_BAT_GPIO_Port GPIOA
#define REF1V65_OUT_Pin GPIO_PIN_2
#define REF1V65_OUT_GPIO_Port GPIOA
#define REF1V65_IN_Pin GPIO_PIN_3
#define REF1V65_IN_GPIO_Port GPIOA
#define V_BAT_Pin GPIO_PIN_4
#define V_BAT_GPIO_Port GPIOA
#define VCAP_Pin GPIO_PIN_2
#define VCAP_GPIO_Port GPIOB
#define TEMP_MOS_Pin GPIO_PIN_11
#define TEMP_MOS_GPIO_Port GPIOB
#define TIM1_BKIN_Pin GPIO_PIN_12
#define TIM1_BKIN_GPIO_Port GPIOB
#define BOOM_IN_Pin GPIO_PIN_13
#define BOOM_IN_GPIO_Port GPIOB
#define TEMP_CAP_Pin GPIO_PIN_15
#define TEMP_CAP_GPIO_Port GPIOB
#define ENABLE_CAP_Pin GPIO_PIN_5
#define ENABLE_CAP_GPIO_Port GPIOB
#define TEST_OUT_Pin GPIO_PIN_9
#define TEST_OUT_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */
#define PLUS

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
